#pragma once

#include <pybind11/pybind11.h>
#include <pybind11/stl.h> // for automatic Python list -> std::vector conversion

namespace kittens {
namespace py {

template<typename T> struct from_object {
    __host__ static T make(pybind11::object obj) {
        return obj.cast<T>();
    }
};
template<ducks::gl::all GL> struct from_object<GL> {
    __host__ static GL make(pybind11::object obj) {
        // Check if argument is a torch.Tensor
        if (pybind11::hasattr(obj, "__class__") && 
            obj.attr("__class__").attr("__name__").cast<std::string>() == "Tensor") {
        
            // Check if tensor is contiguous
            if (!obj.attr("is_contiguous")().cast<bool>()) {
                throw std::runtime_error("Tensor must be contiguous");
            }
            if (obj.attr("device").attr("type").cast<std::string>() == "cpu") {
                throw std::runtime_error("Tensor must be on CUDA device");
            }
            
            // Get shape, pad with 1s if needed
            std::array<int, 4> shape = {1, 1, 1, 1};
            auto py_shape = obj.attr("shape").cast<pybind11::tuple>();
            size_t dims = py_shape.size();
            if (dims > 4) {
                throw std::runtime_error("Expected Tensor.ndim <= 4");
            }
            for (size_t i = 0; i < dims; ++i) {
                shape[4 - dims + i] = pybind11::cast<int>(py_shape[i]);
            }
            
            // Get data pointer using data_ptr()
            uint64_t data_ptr = obj.attr("data_ptr")().cast<uint64_t>();
            
            // Create GL object using make_gl
            return make_gl<GL>(data_ptr, shape[0], shape[1], shape[2], shape[3]);
        }
        throw std::runtime_error("Expected a torch.Tensor");
    }
};

// Extract first argument type from kernel
template<typename T> struct first_arg;
template<typename T> struct first_arg<void(*)(T)> { using type = T; };
template<auto F> using first_arg_t = typename first_arg<decltype(F)>::type;

// Helper to cast a member pointer to the target class. Used for verifying inputs.
template<typename TGlobal, typename MT, typename TBase>
__host__ constexpr MT TGlobal::* member_cast(MT TBase::* p) {
    return static_cast<MT TGlobal::*>(p);
}

template<typename> struct trait;
template<typename> using object = pybind11::object;
template<typename MT, typename T> struct trait<MT T::*> { using member_type = MT; using type = T; };
template<typename T> concept has_dynamic_shared_memory = requires(T t) { { t.dynamic_shared_memory() } -> std::convertible_to<int>; };
template<auto kernel, typename... MemberPtrs> __host__ static void bind_kernel(auto m, auto name, MemberPtrs... member_ptrs) {
    using TGlobal = first_arg_t<kernel>;
    ((void)member_cast<TGlobal>(member_ptrs), ...); // validate pointer compatibility.
    m.def(name, [=](object<MemberPtrs>... args, pybind11::kwargs kwargs) {
        TGlobal __g__ {from_object<typename trait<MemberPtrs>::member_type>::make(args)...};
        cudaStream_t raw_stream = nullptr;
        if (kwargs.contains("stream")) {
            // Extract stream pointer
            uintptr_t stream_ptr = kwargs["stream"].attr("cuda_stream").cast<uintptr_t>();
            raw_stream = reinterpret_cast<cudaStream_t>(stream_ptr);
        }
        if constexpr (has_dynamic_shared_memory<TGlobal>) {
            int __dynamic_shared_memory__ = (int)__g__.dynamic_shared_memory();
            cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, __dynamic_shared_memory__);
            kernel<<<__g__.grid(), __g__.block(), __dynamic_shared_memory__, raw_stream>>>(__g__);
        } else {
            kernel<<<__g__.grid(), __g__.block(), 0, raw_stream>>>(__g__);
        }
    });
}
template<auto function, typename... MemberPtrs> __host__ static void bind_function(auto m, auto name, MemberPtrs... member_ptrs) {
    m.def(name, [=](object<MemberPtrs>... args) {
        using TGlobal = first_arg_t<function>;
        ((void)member_cast<TGlobal>(member_ptrs), ...); // validate pointer compatibility.
        TGlobal __g__ {from_object<typename trait<MemberPtrs>::member_type>::make(args)...};
        function(__g__);
    });
}

} // namespace py
} // namespace kittens
