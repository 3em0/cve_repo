/**
 * @file
 * @brief The ThunderKittens shared tile struct.
 */

#pragma once

#include "../../common/common.cuh"
#include "sv.cuh"

/* ----------  MAIN TILE STRUCT  ---------- */

// these are helper structs for type inference
namespace kittens {
namespace ducks {
/**
 * @namespace st
 *
 * @brief The namespace where concepts and abstract types for shared tiles live.
 */
namespace st {
/**
 * @brief A dummy type used to identify shared tiles.
 * 
 * For a type to quack like an st, it should define its identifier as ducks::st::identifier.
 * If a type quacks like ducks::st::identifier, it will be treated as an st by compiler checks.
 * This is particularly useful for subtiles.
 */
struct identifier {};
/**
* @brief Concept for all shared tiles.
* @tparam T The type to check against the concept requirements.
*
* Requires:
* - T has a nested type identifier that is the same as st::identifier.
*/
template<typename T> concept all = requires {
    typename T::identifier; // Checks if T::identifier exists
} && std::is_same_v<typename T::identifier, identifier>; // Checks if T::identifier is ducks::st::identifier
}
} // namespace ducks

// Forward declaration of subtile
template<
    typename ST,
    int _subtile_height,
    int _subtile_width
>
struct st_subtile;

/**
 * @brief Shared memory tile structure for various data types and layouts.
 *
 * @tparam _T The data type of the elements in the tile. Not packed!
 * @tparam _rows The height of the tile.
 * @tparam _cols The width of the tile.
 */
template<typename _T, int _rows, int _cols, bool _swizzle=true, int _swizzle_bytes=0>
struct KITTENS_DEFAULT_ALIGN st {
    static_assert(!std::is_same_v<_T, char>, "Bare 'char' is not permitted because its signedness is ISA-dependent.");
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
    static_assert(!std::is_same_v<_T, fp4e2m1>, "For FP4 types, you must use a packed type (i.e., fp4e2m1_2 or fp4e2m1_4).");
#endif
    using identifier = ducks::st::identifier; ///< Type identifier for shared memory tile.
    using T = base_types::packing<_T>::unpacked_type;
    using T2 = base_types::packing<_T>::packed_type;
    using dtype = T; ///< Data type of the elements in the tile.
    
    static constexpr bool swizzle = _swizzle;

    // define underlying data as same as that projected, to make clear that this is *not* a subtile.
    static constexpr int underlying_rows          = _rows;
    static constexpr int underlying_cols          = _cols;
    static constexpr int underlying_num_elements  = underlying_rows * underlying_cols;

    static constexpr int rows                = _rows; ///< Total number of rows in the tile.
    static constexpr int cols                = _cols; ///< Total number of cols in the tile.
    static constexpr int num_elements        = rows * cols; ///< Total number of elements in the tile.

    static_assert(!swizzle || (rows % kittens::TILE_ROW_DIM<T> == 0), "Rows must be divisible by the tile dimension");
    static_assert((swizzle && (cols % kittens::TILE_COL_DIM<T> == 0)) || (!swizzle && (cols % kittens::BASE_TILE_DIM == 0)), "Cols must be divisible by the tile dimension");

#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
    // Must be a 1-packed type (e.g. float, bf16, etc) unless fp4
    static_assert(base_types::packing<dtype>::num() == 1 || std::is_same_v<dtype, fp4e2m1_2>); 
#else
    static_assert(base_types::packing<dtype>::num() == 1); 
#endif

    // If a user specifies a swizzle bytes value, the column byte size must be a multiple of the swizzle bytes.
    static_assert(_swizzle_bytes == 0 || _swizzle_bytes == 32 || _swizzle_bytes == 64 || _swizzle_bytes == 128);
    static constexpr int swizzle_bytes = _swizzle_bytes > 0 ? _swizzle_bytes : (
        sizeof(dtype) == 1 ? (  // Add FP8 case
            (cols/kittens::TILE_COL_DIM<T>)%4 == 0 ? 128 :
            (cols/kittens::TILE_COL_DIM<T>)%2 == 0 ?  64 : 32
        ) :
        sizeof(dtype) == 2 ? (
            (cols/kittens::TILE_COL_DIM<T>)%4 == 0 ? 128 :
            (cols/kittens::TILE_COL_DIM<T>)%2 == 0 ?  64 : 32
        ) :
        sizeof(dtype) == 4 ? (
            (cols/kittens::TILE_COL_DIM<T>)%2 == 0 ? 128 : 64
        ) : -1
    );

    dtype data[rows*cols]; ///< Raw data storage for the tile.

    __device__ static inline T* idx(T *ptr, int2 coord) { // naive row-major coord default
        int r = coord.x, c = coord.y; // alias
        if constexpr (swizzle) {
            static constexpr int swizzle_repeat = swizzle_bytes * 8;
            static constexpr int subtile_cols   = swizzle_bytes / sizeof(T);
            const int outer_idx = c/subtile_cols;
            const uint64_t addr = (uint64_t)(&ptr[outer_idx*rows*subtile_cols + r*subtile_cols + c%subtile_cols]);
            const int swizzle = ((addr % swizzle_repeat) >> 7) << 4;
            return (T*)(addr ^ swizzle);
        } else {
            return &ptr[r*cols + c];
        }
    }
    __device__ static inline uint32_t idx(uint32_t ptr, int2 coord) {
        int r = coord.x, c = coord.y; // alias
        if constexpr (swizzle) {
            static constexpr int swizzle_repeat = swizzle_bytes * 8;
            static constexpr int subtile_cols   = swizzle_bytes / sizeof(T);
            const int outer_idx = c/subtile_cols;
            const uint32_t addr = ptr + sizeof(T)*(outer_idx*rows*subtile_cols + r*subtile_cols + c%subtile_cols);
            const int swizzle = ((addr % swizzle_repeat) >> 7) << 4;
            return (addr ^ swizzle);
        } else {
            return ptr + sizeof(T)*(r*cols + c);
        }
    }
    /**
     * @brief Access a shared tile element using a row and column, as if the tile were row-major.
     *
     * This is the preferred way to access memory within a shared tile, which abstracts
     * indexing calculations for swizzled layouts.
     */
    __device__ inline       dtype& operator[](const int2 &rowcol)       {
        return *idx(data, rowcol);
    }
    __device__ inline const dtype& operator[](const int2 &rowcol) const {
        return *(const dtype*)idx((dtype*)data, rowcol);
    }
    __device__ inline       dtype& operator[](int idx)       {
        return data[idx];
    }
    __device__ inline const dtype& operator[](int idx) const {
        return data[idx];
    }

    template<int subtile_rows, int subtile_cols>
    __device__ inline st_subtile<st<_T, _rows, _cols, _swizzle, _swizzle_bytes>, subtile_rows, subtile_cols> subtile(int2 rowcol);

    /**
     * @brief Return a true "subtile" of this tile, not a temporary view with st_subtile. 
     *        The constraint is that only column dimension can be divided, and it must be a multiple of swizzle bytes.
     */
    template<int subtile_cols>
    __device__ inline st<_T, _rows, subtile_cols, _swizzle, swizzle_bytes /*must not use _swizzle_bytes*/> &subtile(int idx) {
        static_assert(swizzle_bytes > 0, "Parent shared tile must have an explicit swizzle_bytes.");
        constexpr int swizzle_elements = swizzle_bytes / sizeof(T);
        static_assert(subtile_cols >= 0 && subtile_cols % swizzle_elements == 0);
        return *reinterpret_cast<st<_T, _rows, subtile_cols, _swizzle, swizzle_bytes> *>(
            &data[rows*swizzle_elements*(subtile_cols/swizzle_elements)*idx]
        );
    }

    // vector types
    using col_vec = sv<dtype, rows>; ///< Column vector type for this tile
    using row_vec = sv<dtype, cols>; ///< Row vector type for this tile
};



/**
 * @brief A reference into a chunk of shared tile memory.
 *
 * The st_subtile is a drop-in replacement for an st which internally
 * references the appropriate memory while performing minimal address
 * calculations. You should never create this directly, but instead
 * have subtile_inplace return it for you instead. (`auto` is nice.)
 *
 * You can generally just pretend this is an st. But not for wgmma's.
 */
template<
    typename _ST,
    int _subtile_rows,
    int _subtile_cols
>
struct st_subtile {
    using identifier = ducks::st::identifier; // i quack like an st, gcc will never know the difference
    using ST = _ST;
    using T = ST::T;
    using T2 = ST::T2;
    using dtype = T; ///< Data type of the elements in the tile.

    static constexpr bool swizzle = ST::swizzle;

    static constexpr int underlying_rows          = ST::underlying_rows;
    static_assert(underlying_rows % kittens::TILE_ROW_DIM<T> == 0, "Underlying rows must be divisible by the tile dimension");
    static constexpr int underlying_cols          = ST::underlying_cols;
    static_assert(underlying_cols % kittens::TILE_COL_DIM<T> == 0, "Underlying cols must be divisible by the tile dimension");
    static constexpr int underlying_num_elements  = ST::underlying_num_elements;

    static constexpr int rows                = _subtile_rows;
    static_assert(rows % kittens::TILE_ROW_DIM<T> == 0, "Rows must be divisible by the tile dimension");
    static constexpr int cols                = _subtile_cols;
    static_assert(cols % kittens::TILE_COL_DIM<T> == 0, "Cols must be divisible by the tile dimension");
    static constexpr int num_elements        = rows * cols;

    static constexpr int swizzle_bytes = ST::swizzle_bytes;

    dtype *data;
    int row_offset, col_offset;

    __device__ st_subtile(ST &src, int2 rowcol) {
        data = &src.data[0];
        row_offset = rowcol.x * rows;
        col_offset = rowcol.y * cols;
    }

    __device__ inline T* idx(T *ptr, const int2 coord) const { // naive row-major coord default
        int r = coord.x+row_offset, c = coord.y+col_offset; // alias
        if constexpr (swizzle) {
            static constexpr int swizzle_repeat = swizzle_bytes * 8;
            static constexpr int subtile_cols   = swizzle_bytes / sizeof(T);
            const int outer_idx = c/subtile_cols;
            const uint64_t addr = (uint64_t)(&ptr[outer_idx*underlying_rows*subtile_cols + r*subtile_cols + c%subtile_cols]);
            const int swizzle = ((addr % swizzle_repeat) >> 7) << 4;
            return (T*)(addr ^ swizzle);
        } else {
            return &ptr[r*cols + c];
        }
    }
    __device__ inline uint32_t idx(uint32_t ptr, const int2 coord) const { // naive row-major coord default
        int r = coord.x+row_offset, c = coord.y+col_offset; // alias
        if constexpr(swizzle) {
            static constexpr int swizzle_repeat = swizzle_bytes * 8;
            static constexpr int subtile_cols   = swizzle_bytes / sizeof(T);
            const int outer_idx = c/subtile_cols;
            const uint32_t addr = ptr + sizeof(T)*(outer_idx*underlying_rows*subtile_cols + r*subtile_cols + c%subtile_cols);
            const int swizzle = ((addr % swizzle_repeat) >> 7) << 4;
            return (addr ^ swizzle);
        } else {
            return ptr + sizeof(T)*(r*cols + c);
        }
    }
    /**
     * @brief Access a shared tile element using a row and column, as if the tile were row-major.
     *
     * This is the preferred way to access memory within a shared tile, which abstracts
     * indexing calculations for swizzled layouts.
     */
    __device__ inline       dtype& operator[](const int2 &rowcol)       {
        return *idx(data, rowcol);
    }
    __device__ inline const dtype& operator[](const int2 &rowcol) const {
        return *(const dtype*)idx((dtype*)data, rowcol);
    }

    // single-coord operator[] is left undefined as it would likely be an improper use of st_subtile type.
    // can of course be end-run by just accessing .data directly.

    // vector types
    using col_vec = sv<dtype, rows>;
    using row_vec = sv<dtype, cols>;

    __device__ inline void operator=(const dtype &value) { // runs at warp scope by default
        #pragma unroll
        for(int i = kittens::laneid(); i < num_elements; i += WARP_THREADS) {
            data[i] = value;
        }
    }
};

template <typename _T, int _rows, int _cols, bool _swizzle, int _swizzle_bytes> // Class template parameters
template <int subtile_rows, int subtile_cols> // Function template parameters
__device__ inline st_subtile<st<_T, _rows, _cols, _swizzle, _swizzle_bytes>, subtile_rows, subtile_cols> // Return type
st<_T, _rows, _cols, _swizzle, _swizzle_bytes>::subtile(int2 rowcol) // Qualified function name and parameters
{
    // Type aliases for convenience within the function body
    using ST_t = st<_T, _rows, _cols>; // Alias for the parent tile type
    using dtype = typename ST_t::dtype;  // Alias for the data type

    // Static assertions (as provided in the initial request)
    static_assert(subtile_rows > 0 && subtile_cols > 0, "Subtile dimensions must be positive.");
    static_assert(subtile_rows % kittens::TILE_ROW_DIM<dtype> == 0,
        "Subtile rows must be divisible by the base tile row dimension.");
    static_assert(subtile_cols % kittens::TILE_COL_DIM<dtype> == 0,
        "Subtile cols must be divisible by the base tile col dimension.");

    // Check divisibility of parent rows/cols by subtile rows/cols
    static_assert(ST_t::rows % subtile_rows == 0,
        "Parent tile rows must be divisible by subtile rows.");
    static_assert(ST_t::cols % subtile_cols == 0,
        "Parent tile cols must be divisible by subtile cols.");

    // Ensure the parent st object is not itself a subtile view by comparing its
    // dimensions to its underlying dimensions.
    static_assert(ST_t::rows == ST_t::underlying_rows && ST_t::cols == ST_t::underlying_cols,
        "Cannot create a subtile from an object that appears to be a subtile view (rows/cols mismatch underlying).");

    // Construct and return the st_subtile object using its constructor:
    // st_subtile(ST &src, int2 rowcol)
    // Here, 'src' is the current 'st' object (*this)
    return st_subtile<ST_t, subtile_rows, subtile_cols>(*this, rowcol);
}

/* ----------  WRAPPERS FOR PRETTINESS  ---------- */

template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_bf = st<bf16,  _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_hf = st<half,  _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_fl = st<float, _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_int8 = st<int8, _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_uint8 = st<uint8, _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_int = st<int, _height, _width, _swizzle, _swizzle_bytes>;
#if defined(KITTENS_SM90) || defined(KITTENS_SM10X) || defined(KITTENS_SM120)
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_fp8e4m3 = st<fp8e4m3, _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_fp8e5m2 = st<fp8e5m2, _height, _width, _swizzle, _swizzle_bytes>;
#endif
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_fp8e8m0 = st<fp8e8m0, _height, _width, _swizzle, _swizzle_bytes>;
template<int _height, int _width, bool _swizzle=true, int _swizzle_bytes=0> 
using st_fp4e2m1_2 = st<fp4e2m1_2, _height, _width, _swizzle, _swizzle_bytes>;
#endif

/* ----------  PRINTOUTS  ---------- */

/**
 * @brief Get a readable type name for shared tiles
 */
template<typename T, int rows, int cols>
__device__ constexpr const char* get_tile_type_name() {
    if constexpr (std::is_same_v<T, float>) {
        return "st_fl";
    } else if constexpr (std::is_same_v<T, half>) {
        return "st_hf";
    } else if constexpr (std::is_same_v<T, bf16>) {
        return "st_bf";
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
    } else if constexpr (std::is_same_v<T, fp4e2m1_2>) {
        return "st_fp4_e2m1_2";
    } else if constexpr (std::is_same_v<T, fp8e8m0>) {
        return "st_fp8_e8m0";
#endif
#if defined(KITTENS_SM90) || defined(KITTENS_SM10X) || defined(KITTENS_SM120)
    } else if constexpr (std::is_same_v<T, fp8e4m3>) {
        return "st_fp8_e4m3";
    } else if constexpr (std::is_same_v<T, fp8e5m2>) {
        return "st_fp8_e5m2";
#endif  
    } else {
        return "st_unknown";
    }
}

#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
/**
 * @brief Print the contents of a shared tile as a formatted table.
 * 
 * This function should be called by a single thread in the warp.
 * It will print the entire tile atomically to avoid interleaved output.
 * 
 * @param tile The shared tile to print
 */
template<ducks::st::all ST>
__device__ inline void print_fp4(const ST& tile) {
    if (std::is_same_v<typename ST::dtype, fp4e2m1>) {

        constexpr int cols = ST::cols * 2;
        printf("Block %d: Shared Tile %dx%d (Type: %s<%d,%d>):\n", blockIdx.x, ST::rows, cols, get_tile_type_name<typename ST::dtype, ST::rows, cols>(), ST::rows, cols);

        // Print column headers
        printf("     "); // Padding for row indices
        for (int c = 0; c < cols; c++) {
            printf("%8d ", c);
        }
        printf("\n");
        
        // Print separator line
        printf("     ");
        for (int c = 0; c < cols; c++) {
            printf("--------+");
        }
        printf("\n");
        
        // Print data rows
        for (int r = 0; r < ST::rows; r++) {
            printf("%3d |", r); // Row index
            for (int c = 0; c < cols; c += 2) {
                uint8_t *vals = reinterpret_cast<uint8_t*>(const_cast<fp4e2m1*>(&tile[{r,c/2}]));

                // Convert to fp4e2m1 and then to float
                float f1 = static_cast<float>(fp4e2m1(vals[0] & 0xF));
                float f2 = static_cast<float>(fp4e2m1((vals[0] >> 4) & 0xF));

                printf("%8.3f %8.3f ", f1, f2);

            }
            printf("\n");
        }
        printf("\n");
    } else {
        printf("Type must be FP4 in this function\n");
    }
}
#endif

/**
 * @brief Print the contents of a shared tile as a formatted table.
 * 
 * This function should be called by a single thread in the warp.
 * It will print the entire tile atomically to avoid interleaved output.
 * 
 * @param tile The shared tile to print
 */
template<ducks::st::all ST>
__device__ inline void print(const ST& tile) {
    printf("Block %d: Shared Tile %dx%d (Type: %s<%d,%d>):\n", blockIdx.x, ST::rows, ST::cols, get_tile_type_name<typename ST::dtype, ST::rows, ST::cols>(), ST::rows, ST::cols);
    
    // Print column headers
    printf("     "); // Padding for row indices
    for (int c = 0; c < ST::cols; c++) {
        printf("%8d ", c);
    }
    printf("\n");
    
    // Print separator line
    printf("     ");
    for (int c = 0; c < ST::cols; c++) {
        printf("--------+");
    }
    printf("\n");
    
    // Print data rows
    for (int r = 0; r < ST::rows; r++) {
        printf("%3d |", r); // Row index
        for (int c = 0; c < ST::cols; c++) {
            if constexpr (std::is_same_v<typename ST::dtype, float>) {
                printf("%8.3f ", tile[{r,c}]);
            } else if constexpr (std::is_same_v<typename ST::dtype, __nv_bfloat16>) {
                printf("%8.3f ", __bfloat162float(tile[{r,c}]));
            } else if constexpr (std::is_integral_v<typename ST::dtype>) {
                printf("%8d ", (int)tile[{r,c}]);
#if defined(KITTENS_SM90) || defined(KITTENS_SM10X) || defined(KITTENS_SM120)
            } else if constexpr (std::is_same_v<typename ST::dtype, fp8e4m3>) {
                printf("%8.3f ", static_cast<float>(tile[{r,c}]));
            } else if constexpr (std::is_same_v<typename ST::dtype, fp8e5m2>) {
                printf("%8.3f ", static_cast<float>(tile[{r,c}]));
#endif
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
            } else if constexpr (std::is_same_v<typename ST::dtype, fp8e8m0>) {
                printf("%8.3f ", static_cast<float>(tile[{r,c}]));
#endif
            } else {
                printf("%8.3f ", (float)tile[{r,c}]);
            }
        }
        printf("\n");
    }
    printf("\n");
}

/**
 * @brief Print the contents of a shared subtile as a formatted table.
 * 
 * This function prints subtiles with additional information about their position
 * within the parent tile.
 * 
 * @param subtile The shared subtile to print
 */
template<typename ST, int subtile_rows, int subtile_cols>
__device__ inline void print(const st_subtile<ST, subtile_rows, subtile_cols>& subtile) {
    printf("Block %d: Shared Subtile %dx%d (offset: [%d,%d], Type: %s<%d,%d> from %s<%d,%d>):\n", 
            blockIdx.x, subtile.rows, subtile.cols, 
            subtile.row_offset, subtile.col_offset,
            get_tile_type_name<typename ST::dtype, subtile.rows, subtile.cols>(), subtile.rows, subtile.cols,
            get_tile_type_name<typename ST::dtype, ST::rows, ST::cols>(), ST::rows, ST::cols);
    
    // Print column headers
    printf("     "); // Padding for row indices
    for (int c = 0; c < subtile.cols; c++) {
        printf("%8d ", c);
    }
    printf("\n");
    
    // Print separator line
    printf("     ");
    for (int c = 0; c < subtile.cols; c++) {
        printf("--------+");
    }
    printf("\n");
    
    // Print data rows
    for (int r = 0; r < subtile.rows; r++) {
        printf("%3d |", r); // Row index
        for (int c = 0; c < subtile.cols; c++) {
            if constexpr (std::is_same_v<typename ST::dtype, float>) {
                printf("%8.3f ", subtile[{r,c}]);
            } else if constexpr (std::is_same_v<typename ST::dtype, __nv_bfloat16>) {
                printf("%8.3f ", __bfloat162float(subtile[{r,c}]));
            } else if constexpr (std::is_integral_v<typename ST::dtype>) {
                printf("%8d ", (int)subtile[{r,c}]);
            } else {
                printf("%8.3f ", (float)subtile[{r,c}]);
            }
        }
        printf("\n");
    }
    printf("\n");
}

/**
 * @brief Fill a shared tile with ones.
 * 
 * This function should be called by a single thread in the warp.
 * It will fill the entire tile with 1s (value, not bits) in the tile.
 * 
 * @param tile The shared tile to fill with 1s
 */
template<ducks::st::all ST>
__device__ inline void fill_value(ST& tile, float value) {
    printf("Filling Tile %dx%d with %f:\n", ST::rows, ST::cols, value);

    // Fill tile with value
    for (int r = 0; r < ST::rows; r++) {
        for (int c = 0; c < ST::cols; c++) {
            if constexpr (std::is_same_v<typename ST::dtype, float>) {
                tile[{r,c}] = value;
            } else if constexpr (std::is_same_v<typename ST::dtype, __nv_bfloat16>) {
                tile[{r,c}] = __float2bfloat16(value);
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
            } else if constexpr (std::is_same_v<typename ST::dtype, fp4e2m1>) {
                tile.data[r*ST::cols + c] = fp4e2m1(value);
            } else if constexpr (std::is_same_v<typename ST::dtype, fp8e8m0>) {
                tile.data[r*ST::cols + c] = fp8e8m0(value);
#endif
            } else {    
                tile[{r,c}] = value;
            }
        }
    }
}

/**
 * @brief Fill a shared tile with something!
 * 
 * This function should be called by a single thread in the warp.
 * It will fill the entire tile with 1s (value, not bits) in the tile.
 * 
 * @param tile The shared tile to fill with 1s
 */
template<ducks::st::all ST>
__device__ inline void fill_identity(ST& tile) {
    printf("Filling Tile %dx%d with identity:\n", ST::rows, ST::cols);
    
    // Print data rows
    for (int r = 0; r < ST::rows; r++) {
        for (int c = 0; c < ST::cols; c++) {
            if constexpr (std::is_same_v<typename ST::dtype, float>) {
                // printf("%8.3f ", tile[{r,c}]);
                tile[{r,c}] = 1.0f;
            } else if constexpr (std::is_same_v<typename ST::dtype, __nv_bfloat16>) {
                // printf("%8.3f ", __bfloat162float(tile[{r,c}]));
                tile[{r,c}] = __float2bfloat16(1.0f);
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
            } else if constexpr (std::is_same_v<typename ST::dtype, fp4e2m1>) {
                if(r == c){
                    // tile[{r,c}] = std::bit_cast<fp4e2m1>(uint8_t(0xFF));
                    tile.data[r*ST::cols + c] = std::bit_cast<fp4e2m1>(uint8_t(0xFF));
                } else {
                    tile.data[r*ST::cols + c] = std::bit_cast<fp4e2m1>(uint8_t(0x00));
                }
#endif
            } else {    
                // printf("%8.3f ", (float)tile[{r,c}]);
            }
        }
    }
}

/**
 * @brief Print the contents of a shared tile as a formatted table in bits.
 * 
 * This function should be called by a single thread in the warp.
 * It will print the entire tile atomically to avoid interleaved output.
 * Each element will be printed as a bitfield
 * 
 * @param tile The shared tile to print
 */
template<ducks::st::all ST>
__device__ inline void print_bits(const ST& tile, bool unswizzle = false) {
    printf("Block %d: Shared Tile %dx%d (Type: %s<%d,%d>):\n", blockIdx.x, ST::rows, ST::cols, get_tile_type_name<typename ST::dtype, ST::rows, ST::cols>(), ST::rows, ST::cols);
    
    // Print column headers
    printf(" "); // Padding for row indices
    for (int c = 0; c < ST::cols; c++) {
        printf("%11d ", c);
    }
    printf("\n");
    
    // Print separator line
    printf("     ");
    for (int c = 0; c < ST::cols; c++) {
        printf("-----------+");
    }
    printf("\n");
    
    // Print data rows
    for (int r = 0; r < ST::rows; r++) {
        printf("%3d |", r); // Row index
        for (int c = 0; c < ST::cols; c++) {
            if constexpr (std::is_same_v<typename ST::dtype, float>) {
                printf("%8.3f ", tile[{r,c}]);
            } else if constexpr (std::is_same_v<typename ST::dtype, __nv_bfloat16>) {
                printf("%8.3f ", __bfloat162float(tile[{r,c}]));
            // } else if constexpr (std::is_integral_v<typename ST::dtype>) {
            //     printf("%8d ", (int)tile[{r,c}]);
#if defined(KITTENS_SM10X) || defined(KITTENS_SM120)
            } else if constexpr (std::is_same_v<typename ST::dtype, fp4e2m1> || std::is_same_v<typename ST::dtype, fp8e8m0>) {
                // print as bitfield

                uint8_t bits;
                if(unswizzle){
                    bits = *reinterpret_cast<const uint8_t*>(&tile.data[r*ST::cols + c]); // Assuming 4-bit value
                } else {
                    bits = *reinterpret_cast<const uint8_t*>(&tile[{r,c}]); // Assuming 4-bit value
                }
                // Print all 32 bits with formatting for readability
                printf("0b");
                // Print in groups of 4 for readability
                for (int bit = 7; bit >= 0; bit--) {
                    printf("%d", (bits >> bit) & 0x1);
                    if (bit % 4 == 0 && bit > 0) printf("_");
                }
                printf(" ");
#endif
            } else {
                printf("%8.3f ", (float)tile[{r,c}]);
            }
        }
        printf("\n");
    }
    printf("\n");
}

} // namespace kittens
