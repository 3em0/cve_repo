/**
 * @file
 * @brief Utilities for Tensor Memory Accelerator (TMA)
 */

#pragma once

#include "../../../common/common.cuh"
#include "../../../types/types.cuh"
#include "sync.cuh"

namespace kittens {
/**
 * @brief A namespace for all of ThunderKittens' TMA functionality.
*/
namespace tma {

/* ----------   Barrier functions for async load  ---------- */

/**
* @brief Sets the number of bytes expected at the semaphore.
*
* This function sets the number of bytes expected at the semaphore for the first thread in the warp.
* It converts the semaphore pointer to a generic shared memory pointer and uses an inline assembly
* instruction to set the expected number of bytes.
*
* @param bar Reference to the semaphore variable.
* @param bytes The number of bytes expected at the semaphore.
*/
__device__ static inline void expect_bytes(semaphore& bar, uint32_t bytes) {
    void const* const ptr = &bar;
    uint32_t bar_ptr = static_cast<uint32_t>(__cvta_generic_to_shared(ptr)); 

    asm volatile ("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;\n"
        :: "r"(bar_ptr), "r"(bytes));
}
/**
* @brief Sets the number of bytes expected at the semaphore.
*
* This function sets the number of bytes expected at the mbarrier before the transaction arrives.
*/
template<typename T, typename... args>
__device__ static inline void expect(semaphore& bar, const T& _1, const args&... _2) {
    expect_bytes(bar, size_bytes<T, args...>);
}

/* ----------   Synchronization functions for async store  ---------- */

/**
 * @brief Commits previous asynchronous TMA stores to a group and performs them.
*/
__device__ static inline void store_commit_group() {
    asm volatile("cp.async.bulk.commit_group;");
}
/**
 * @brief Waits for previous committed TMA store groups to complete.
 *
 * @tparam N The maximum number of remaining TMA store groups. Defaults to 0.
*/
template <int N=0>
__device__ static inline void store_async_wait() {
    asm volatile (
        "cp.async.bulk.wait_group %0;"
        :
        : "n"(N)
        : "memory"
    );
}
/**
 * @brief Waits for previous committed TMA store groups to finish reading from shared memory.
 *
 * @tparam N The maximum number of remaining TMA store groups. Defaults to 0.
*/
template <int N=0>
__device__ static inline void store_async_read_wait() {
    asm volatile (
        "cp.async.bulk.wait_group.read %0;"
        :
        : "n"(N)
        : "memory"
    );
}

/* ------- Non-tensor TMA transfers ------- */

__device__ static inline void load_async(void *dst, void *src, uint32_t size_bytes, semaphore& bar) {
    asm volatile (
        "cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];\n"
        :: "r"(static_cast<uint32_t>(__cvta_generic_to_shared(dst))), 
           "l"(src), "r"(size_bytes), 
           "r"(static_cast<uint32_t>(__cvta_generic_to_shared(&bar)))
        : "memory"
    );
}
template<typename T>
__device__ static inline void load_async(T &dst, T &src, uint32_t size_bytes, semaphore& bar) {
    load_async(reinterpret_cast<void*>(&dst), reinterpret_cast<void*>(&src), size_bytes, bar);
}

__device__ static inline void store_async(void *dst, void *src, uint32_t size_bytes) {
    asm volatile ("fence.proxy.async.shared::cta;\n" ::: "memory");
    asm volatile (
        "cp.async.bulk.global.shared::cta.bulk_group [%0], [%1], %2;\n"
        :: "l"(dst), "r"(static_cast<uint32_t>(__cvta_generic_to_shared(src))), "r"(size_bytes)
        : "memory"
    );
    store_commit_group();
}
template<typename T>
__device__ static inline void store_async(T &dst, T &src, uint32_t size_bytes) {
    store_async(reinterpret_cast<void*>(&dst), reinterpret_cast<void*>(&src), size_bytes);
}

/* ----------   Cluster-scope operations  ---------- */

namespace cluster {

/**
* @brief Waits for the requested semaphore phase, at cluster scope
*
* @param bar Reference to the semaphore variable.
* @param kPhaseBit The phase bit used for the semaphore.
*/
template <memory_model M = memory_model::ACQUIRE>
__device__ static inline void wait(semaphore& bar, int kPhaseBit) {
    static_assert(M == memory_model::RELAXED || M == memory_model::ACQUIRE, "mbarrier waits support relaxed or acquire semantics");
    void const* const ptr = &bar;
    uint32_t mbar_ptr = static_cast<uint32_t>(__cvta_generic_to_shared(ptr)); 

    if constexpr (M == memory_model::RELAXED) {
        asm volatile (
            "{\n"
            ".reg .pred                P1;\n"
            "LAB_WAIT:\n"
            "mbarrier.try_wait.parity.relaxed.cluster.shared::cta.b64 P1, [%0], %1;\n"
            "@P1                       bra.uni DONE;\n"
            "bra.uni                   LAB_WAIT;\n"
            "DONE:\n"
            "}\n"
            :: "r"(mbar_ptr), "r"(kPhaseBit)
        );
    } else {
        asm volatile (
            "{\n"
            ".reg .pred                P1;\n"
            "LAB_WAIT:\n"
            "mbarrier.try_wait.parity.acquire.cluster.shared::cta.b64 P1, [%0], %1;\n"
            "@P1                       bra.uni DONE;\n"
            "bra.uni                   LAB_WAIT;\n"
            "DONE:\n"
            "}\n"
            :: "r"(mbar_ptr), "r"(kPhaseBit)
            : "memory"
        );
    }
}

template <memory_model M = memory_model::ACQUIRE>
__device__ static inline bool try_wait(semaphore &bar, int kPhaseBit) {
    static_assert(M == memory_model::RELAXED || M == memory_model::ACQUIRE, "mbarrier waits support relaxed or acquire semantics");
    void const* const ptr = &bar;
    uint32_t mbar_ptr = static_cast<uint32_t>(__cvta_generic_to_shared(ptr)); 
    uint32_t success;

    if constexpr (M == memory_model::RELAXED) {
        asm volatile(
            "{\n"
            ".reg .pred P1; \n"
            "mbarrier.try_wait.parity.relaxed.cluster.shared::cta.b64 P1, [%1], %2; \n"
            "selp.b32 %0, 1, 0, P1; \n"
            "}\n"
            : "=r"(success)
            : "r"(mbar_ptr), "r"(kPhaseBit)
        );
    } else {
        asm volatile(
            "{\n"
            ".reg .pred P1; \n"
            "mbarrier.try_wait.parity.acquire.cluster.shared::cta.b64 P1, [%1], %2; \n"
            "selp.b32 %0, 1, 0, P1; \n"
            "}\n"
            : "=r"(success)
            : "r"(mbar_ptr), "r"(kPhaseBit)
            : "memory"
        );
    }

    return static_cast<bool>(success);
}

template <memory_model M = memory_model::ACQUIRE>
__device__ static inline void careful_wait(semaphore& bar, int kPhaseBit) {
    static_assert(M == memory_model::RELAXED || M == memory_model::ACQUIRE, "mbarrier waits support relaxed or acquire semantics");
    void const* const ptr = &bar;
    uint32_t mbar_ptr = static_cast<uint32_t>(__cvta_generic_to_shared(ptr)); 

    if constexpr (M == memory_model::RELAXED) {
        asm volatile (
            "{\n"
            ".reg .b64                 start_clock, current_clock;\n"
            "mov.b64                   start_clock, %clock64;\n"
            ".reg .pred                P_CLOCK;\n"
            ".reg .pred                P1;\n"
            "LAB_WAIT:\n"
            "mbarrier.try_wait.parity.relaxed.cluster.shared::cta.b64 P1, [%0], %1;\n"
            "@P1                       bra.uni DONE;\n"
            "mov.b64                   current_clock, %clock64;\n"
            "sub.u64                   current_clock, current_clock, start_clock;\n"
            "setp.ge.u64               P_CLOCK, current_clock, 1000000;\n"
            "@P_CLOCK                  trap;\n"
            "bra.uni                   LAB_WAIT;\n"
            "DONE:\n"
            "}\n"
            :: "r"(mbar_ptr), "r"(kPhaseBit)
        );
    } else {
        asm volatile (
            "{\n"
            ".reg .b64                 start_clock, current_clock;\n"
            "mov.b64                   start_clock, %clock64;\n"
            ".reg .pred                P_CLOCK;\n"
            ".reg .pred                P1;\n"
            "LAB_WAIT:\n"
            "mbarrier.try_wait.parity.acquire.cluster.shared::cta.b64 P1, [%0], %1;\n"
            "@P1                       bra.uni DONE;\n"
            "mov.b64                   current_clock, %clock64;\n"
            "sub.u64                   current_clock, current_clock, start_clock;\n"
            "setp.ge.u64               P_CLOCK, current_clock, 1000000;\n"
            "@P_CLOCK                  trap;\n"
            "bra.uni                   LAB_WAIT;\n"
            "DONE:\n"
            "}\n"
            :: "r"(mbar_ptr), "r"(kPhaseBit)
            : "memory"
        );
    }
}

/**
* @brief Sets the number of bytes expected at the semaphore, assuming a multicast instruction.
*
* This function sets the number of bytes expected at the semaphore for the first thread in the warp.
* It converts the semaphore pointer to a generic shared memory pointer and uses an inline assembly
* instruction to set the expected number of bytes.
* 
* It's worth being aware that this function is particularly necessary for multicast loads, and
* distributed shared memory can actually be done with a normal tma::expect followed by wait. See
* the unit tests of dsmem for an example.
*
* @param bar Reference to the semaphore variable.
* @param bytes The number of bytes expected at the semaphore.
*/
template <memory_model M = memory_model::RELEASE>
__device__ static inline void expect_bytes(semaphore& bar, uint32_t bytes) {
    static_assert(M == memory_model::RELAXED || M == memory_model::RELEASE, "mbarrier.arrive.expect_tx supports relaxed or release semantics");
    uint32_t mbar_addr = static_cast<uint32_t>(__cvta_generic_to_shared(&bar));
    if constexpr (M == memory_model::RELAXED) {
        asm volatile ("mbarrier.arrive.expect_tx.relaxed.cluster.shared::cluster.b64 _, [%0], %1;\n"
            :: "r"(mbar_addr), "r"(bytes));
    } else {
        asm volatile ("mbarrier.arrive.expect_tx.shared::cluster.b64 _, [%0], %1;\n"
            :: "r"(mbar_addr), "r"(bytes));
    }
}
template <memory_model M = memory_model::RELEASE>
__device__ static inline void expect_bytes(semaphore& bar, uint32_t bytes, int dst_cta) {
    static_assert(M == memory_model::RELAXED || M == memory_model::RELEASE, "mbarrier.arrive.expect_tx supports relaxed or release semantics");
    uint32_t mbar_addr = static_cast<uint32_t>(__cvta_generic_to_shared(&bar)); 
    uint32_t neighbor_mbar_addr;
    asm volatile (
        "mapa.shared::cluster.u32  %0, %1, %2;\n"
        : "=r"(neighbor_mbar_addr)
        : "r"(mbar_addr), "r"(dst_cta)
    );
    if constexpr (M == memory_model::RELAXED) {
        asm volatile ("mbarrier.arrive.expect_tx.relaxed.cluster.shared::cluster.b64 _, [%0], %1;\n"
            :: "r"(neighbor_mbar_addr), "r"(bytes));
    } else {
        asm volatile ("mbarrier.arrive.expect_tx.shared::cluster.b64 _, [%0], %1;\n"
            :: "r"(neighbor_mbar_addr), "r"(bytes));
    }
}
/**
* @brief Sets the number of bytes expected at the semaphore.
*
* This function sets the number of bytes expected at the semaphore for the first thread in the warp.
* It converts the semaphore pointer to a generic shared memory pointer and uses an inline assembly
* instruction to set the expected number of bytes.
*
* @tparam T The type of the data to be stored at the semaphore.
* @param semaphore Reference to the semaphore variable.
*/
/**
* @brief Sets the number of bytes expected at the semaphore.
*
* This function sets the number of bytes expected at the mbarrier before the transaction arrives.
*/
template<memory_model M = memory_model::RELEASE, typename T, typename... args>
__device__ static inline void expect(semaphore& bar, const T& _1, const args&... _2) {
    expect_bytes<M>(bar, size_bytes<T, args...>);
}

/**
* @brief Arrives at a semaphore in cluster scope.
*
* Marks a thread arrival at an mbarrier
*
* @param bar Reference to the semaphore variable.
* @param dst_cta The destination CTA index.
* @param count The count value for the arrival.
*/
template <memory_model M = memory_model::RELEASE>
__device__ static inline void arrive(semaphore& bar, int dst_cta, uint32_t count=1) {
    static_assert(M == memory_model::RELAXED || M == memory_model::RELEASE, "mbarrier arrive supports relaxed or release semantics");
    uint32_t mbar_addr = static_cast<uint32_t>(__cvta_generic_to_shared(&bar)); 
    uint32_t neighbor_mbar_addr;
    asm volatile (
        "mapa.shared::cluster.u32  %0, %1, %2;\n"
        : "=r"(neighbor_mbar_addr)
        : "r"(mbar_addr), "r"(dst_cta)
    );
    if constexpr (M == memory_model::RELAXED) {
        asm volatile (
            "mbarrier.arrive.relaxed.cluster.shared::cluster.b64 _, [%0], %1;\n"
            :
            : "r"(neighbor_mbar_addr), "r"(count)
        );
    } else {
        asm volatile (
            "mbarrier.arrive.shared::cluster.b64 _, [%0], %1;\n"
            :
            : "r"(neighbor_mbar_addr), "r" (count)
            : "memory"
        );
    }
}

/* ------- Non-tensor TMA transfers ------- */

__device__ static inline void load_async(void *dst, void *src, uint32_t size_bytes, semaphore& bar, cluster_mask_t cta_mask) {
    asm volatile (
        "cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes.multicast::cluster" KITTENS_MCAST_SUFFIX
        " [%0], [%1], %2, [%3], %4;\n"
        :: "r"(static_cast<uint32_t>(__cvta_generic_to_shared(dst))),
           "l"(src), "r"(size_bytes),
           "r"(static_cast<uint32_t>(__cvta_generic_to_shared(&bar))),
           KITTENS_MCAST_OPERAND(cta_mask)
        : "memory"
    );
}
template<typename T>
__device__ static inline void load_async(T &dst, T &src, uint32_t size_bytes, semaphore& bar, cluster_mask_t cta_mask) {
    load_async(reinterpret_cast<void*>(&dst), reinterpret_cast<void*>(&src), size_bytes, bar, cta_mask);
}

} // namespace cluster
} // namespace tma
} // namespace kittens
