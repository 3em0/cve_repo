import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import torch

from common import (
    init_distributed_environment,
    destroy_distributed_environment,
    check_diff,
    benchmark_no_l2_clear,
    profile,
    clean_print
)

from _C import TKParallelTensor, tk_reduce_scatter


def nccl_reduce_scatter_func(
    output: torch.Tensor,
    input: torch.Tensor,
    local_world_size: int
) -> None:
    """
    NCCL ReduceScatter on tensor dimension.
    """
    input_reshaped = input.movedim(-1, 0).contiguous()
    output_reshaped = torch.empty(
        (input_reshaped.shape[0] // local_world_size, *input_reshaped.shape[1:]),
        device=input.device, dtype=input.dtype
    )
    torch.distributed.reduce_scatter_tensor(output_reshaped, input_reshaped, op=torch.distributed.ReduceOp.SUM)
    output.copy_(output_reshaped.movedim(0, -1))


def tk_reduce_scatter_func(
    output: TKParallelTensor,
    input: TKParallelTensor,
    barrier: TKParallelTensor
) -> None:
    tk_reduce_scatter(output, input, barrier)


def run(
    N: int,
    local_rank: int,
    local_world_size: int,
    num_warmup_iters: int = 1,
    num_iters: int = 5,
    check_correctness: bool = False,
    do_profile: bool = False
) -> None:
    input_tensor_tk = TKParallelTensor(
        (N, N), 
        dtype=torch.bfloat16, 
        local_rank=local_rank, 
        local_world_size=local_world_size, 
        multicast=True
    )
    torch.randn((N, N), out=input_tensor_tk.data_)
    output_tensor_tk = TKParallelTensor(
        (N, N // local_world_size), 
        dtype=torch.bfloat16,
        local_rank=local_rank,
        local_world_size=local_world_size,
        multicast=False
    )
    output_tensor_tk.data_.zero_()
    barrier_tk = TKParallelTensor(
        (1, 1),
        dtype=torch.int,
        local_rank=local_rank,
        local_world_size=local_world_size,
        multicast=True
    )
    barrier_tk.data_.zero_()

    # Must wait for all barriers to be initialized before running the kernel
    torch.distributed.barrier()

    input_tensor_nccl = input_tensor_tk.data_.clone()
    output_tensor_nccl = output_tensor_tk.data_.clone()

    nccl_func = lambda: nccl_reduce_scatter_func(output_tensor_nccl, input_tensor_nccl, local_world_size)
    tk_func = lambda: tk_reduce_scatter_func(output_tensor_tk, input_tensor_tk, barrier_tk)

    if check_correctness:
        nccl_func()
        tk_func()
        check_diff("ReduceScatter Diff Comparison", output_tensor_tk.data_, output_tensor_nccl)

    if do_profile:
        torch.distributed.barrier()
        torch.cuda.synchronize()
        combined = lambda: (nccl_func(), tk_func())
        profile(combined, num_iters)

    nccl_avg_ms = benchmark_no_l2_clear(nccl_func, num_warmup_iters, num_iters)
    tk_avg_ms = benchmark_no_l2_clear(tk_func, num_warmup_iters, num_iters)

    clean_print(f"===============================================================================", print_once=True)
    clean_print(f"<BF16 ReduceScatter | world_size={local_world_size} | {N}x{N}>", print_once=True)
    clean_print(f"NCCL: {nccl_avg_ms:.3f} ms")
    clean_print(f"TK: {tk_avg_ms:.3f} ms")

if __name__ == "__main__":
    local_rank, local_world_size = init_distributed_environment()
    for N in [4096, 8192, 16384, 32768, 65536]:
        run(N, local_rank, local_world_size, check_correctness=False, do_profile=False)
    destroy_distributed_environment()
