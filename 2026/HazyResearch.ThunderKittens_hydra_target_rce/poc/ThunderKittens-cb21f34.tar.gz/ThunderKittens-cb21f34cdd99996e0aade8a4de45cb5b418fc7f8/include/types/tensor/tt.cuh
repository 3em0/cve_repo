/**
 * @file
 * @brief The ThunderKittens tensor memory tile struct.
 */

#pragma once

#include "../../common/common.cuh"

/* ----------  MAIN tt STRUCT  ---------- */

// these are helper structs for type inference
namespace kittens {

constexpr int MAX_TENSOR_ROWS = 128;
constexpr int MAX_TENSOR_COLS = 512;
#ifdef KITTENS_SM107
constexpr int MAX_TENSOR_COLS_EXCLUSIVE = 576;
#else
constexpr int MAX_TENSOR_COLS_EXCLUSIVE = MAX_TENSOR_COLS;
#endif

namespace ducks {
/**
 * @namespace tt
 * 
 * @brief The namespace where concepts and abstract types for tensor tiles live.
 */
namespace tt {
/**
 * @brief A dummy type used to identify tensor memory.
 */
struct identifier {};
/**
* @brief Concept for all tt tiles.
* @tparam T The type to check against the concept requirements.
*
* Requires:
* - T has a nested type identifier that is the same as tt::identifier.
*/
template<typename T> concept all = requires {
    typename T::identifier; // Checks if T::identifier exists
} && std::is_same_v<typename T::identifier, identifier>; // Checks if T::identifier is ducks::tt::identifier
template<typename T> concept half = all<T> && T::rows == MAX_TENSOR_ROWS / 2;
template<typename T> concept full = all<T> && T::rows == MAX_TENSOR_ROWS;
} // namespace tt
} // namespace ducks

/**
 * @brief Tensor memory tile structure for various data types and layouts.
 *
 * @tparam _T The data type of the elements in the tile. Not packed!
 * @tparam _rows The height of the tile.
 * @tparam _cols The width of the tile.
 */
template<typename _T, int _rows, int _cols>
struct tt {
    static_assert(!std::is_same_v<_T, char>, "Bare 'char' is not permitted because its signedness is ISA-dependent.");
    using identifier = ducks::tt::identifier; ///< Type identifier for tensor memory tile.
    using T = base_types::packing<_T>::unpacked_type;
    using T2 = base_types::packing<_T>::packed_type;
    using dtype = T; ///< Data type of the elements in the tile.

    static constexpr int rows    = _rows;
    static constexpr int cols    = _cols;

    static_assert(rows / (4 / sizeof(T)) <= MAX_TENSOR_ROWS, "Row dimension must be less than or equal to MAX_TENSOR_ROWS");
    static_assert(cols / (4 / sizeof(T)) <= MAX_TENSOR_COLS, "Column dimension must be less than or equal to MAX_TENSOR_COLS");
    static_assert(rows % kittens::BASE_TILE_DIM == 0, "Row dimension must be divisible by the 16");
    static_assert(cols % kittens::BASE_TILE_DIM == 0, "Column dimension must be divisible by the 16");

    uint32_t addr;

    __device__ inline tt() : addr(0) {}
    __device__ inline tt(uint32_t addr) : addr(addr) {}

    template<ducks::tt::all TT>  __device__ inline TT subtile(int row_offset, int col_offset) const {
#ifndef NDEBUG
        if(row_offset < 0 || row_offset+TT::rows > rows || col_offset < 0 || col_offset+TT::cols > cols) {
            printf("Subtile out of bounds! full tile rows: %d, full tile cols: %d, subtile rows: %d, subtile cols: %d, row_offset: %d, col_offset: %d\n", rows, cols, TT::rows, TT::cols, row_offset, col_offset);
            asm volatile("trap;");
        }
#endif
        return TT(addr + (row_offset<<16) + col_offset/(4/(uint32_t)sizeof(T)));
    }
    template<ducks::tt::all TT>  __device__ inline TT subtile(int col_offset) const {
        return TT(addr + col_offset/(4/(uint32_t)sizeof(T)));
    }
    template<int transpose> __device__ inline uint32_t chunk_addr(int chunk) const {
        if constexpr (transpose) {
            static_assert(!transpose, "Transposed TMEM chunk addressing is not supported due to Blackwell tensor-core limitations.");
        }
        else {
            if constexpr (std::is_same_v<T, bf16> || std::is_same_v<T, half>) {
                return addr + (16 * chunk / (4/(uint32_t)sizeof(T)));
            }
            else if constexpr (std::is_same_v<T, fp8e4m3> || std::is_same_v<T, fp8e5m2> || std::is_same_v<T, int8> || std::is_same_v<T, uint8>) {
                return addr + (32 * chunk / (4/(uint32_t)sizeof(T)));
            }
            else {
                static_assert(sizeof(T) == 999, "Currently unsupported type for input to an mma.");
            }
        }
    }
};

/* ----------  WRAPPERS FOR PRETTINESS  ---------- */

template<int _height, int _width> using tt_bf = tt<bf16, _height, _width>;
template<int _height, int _width> using tt_hf = tt<half, _height, _width>;
template<int _height, int _width> using tt_fl = tt<float, _height, _width>;
template<int _height, int _width> using tt_int8 = tt<int8, _height, _width>;
template<int _height, int _width> using tt_uint8 = tt<uint8, _height, _width>;
template<int _height, int _width> using tt_int = tt<int, _height, _width>;
template<int _height, int _width> using tt_fp8e4m3 = tt<fp8e4m3, _height, _width>;
template<int _height, int _width> using tt_fp8e5m2 = tt<fp8e5m2, _height, _width>;
template<int _height, int _width> using tt_fp8e8m0 = tt<fp8e8m0, _height, _width>;
template<int _height, int _width> using tt_fp4e2m1_2 = tt<fp4e2m1_2, _height, _width>;
template<int _width> using half_tt_bf = tt<bf16, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_hf = tt<half, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_fl = tt<float, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_int8 = tt<int8, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_uint8 = tt<uint8, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_int = tt<int, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_fp8e4m3 = tt<fp8e4m3, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_fp8e5m2 = tt<fp8e5m2, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_fp8e8m0 = tt<fp8e8m0, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using half_tt_fp4e2m1_2 = tt<fp4e2m1_2, MAX_TENSOR_ROWS / 2, _width>;
template<int _width> using full_tt_bf = tt<bf16, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_hf = tt<half, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_fl = tt<float, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_int8 = tt<int8, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_uint8 = tt<uint8, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_int = tt<int, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_fp8e4m3 = tt<fp8e4m3, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_fp8e5m2 = tt<fp8e5m2, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_fp8e8m0 = tt<fp8e8m0, MAX_TENSOR_ROWS, _width>;
template<int _width> using full_tt_fp4e2m1_2 = tt<fp4e2m1_2, MAX_TENSOR_ROWS, _width>;

} // namespace kittens
